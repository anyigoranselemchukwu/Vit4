{pkgs}: {
  deps = [
    pkgs.nano
    pkgs.u-root-cmds
    pkgs.unzip
  ];
}
